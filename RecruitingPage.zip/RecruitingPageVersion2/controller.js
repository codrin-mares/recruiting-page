console.log('Hi Controller!');

function sendEmail() {
  Email.send({
    Host: "smtp.gmail.com",
    Username: "sender@email_address.com",
    Password: "Enter your password",
    To: 'receiver@email_address.com',
    From: "sender@email_address.com",
    Subject: "Sending Email using javascript",
    Body: "Well that was easy!!",
  })
    .then(function (message) {
      alert("mail sent successfully")
    });
}

let formValues = undefined;

function handleSubmit(e) {
  e.preventDefault();
  const formData = new FormData(e.target);
  const formProps = Object.fromEntries(formData);

  formValues = {...formProps};
  // alert(`Email sent with: ${JSON.stringify(formProps)}`, );

  showEnvelope();
}

function confirmSubmit() {
  // alert(`Email sent with: ${JSON.stringify(formValues)}`, );
  showClosingScene();
}

const recruitmentForm = document.getElementById("recruitment-form");
recruitmentForm?.addEventListener("submit", handleSubmit);

const openingScene = document.getElementById("opening");
const openingWrapper = document.getElementById("opening-wrapper");
const closingScene = document.getElementById("closing");
const closingWrapper = document.getElementById("closing-wrapper");
const replayBtn = document.getElementById("replay-btn");
const replayBtn2 = document.getElementById("replay-btn2");
const paper = document.getElementById("paper-wrapper");
const envelope = document.getElementById("envelope");
const replayScene = document.getElementById("replay-scene");
const replaySceneWrapper = document.getElementById("replay-scene-wrapper");

openingScene?.addEventListener('ended', () => {
  openingWrapper.style.display = 'none';
  paper.classList.add('fade-in-transition');
});

closingScene?.addEventListener('ended', () => {
  replayBtn.style.display = 'block';
})

replayScene?.addEventListener('ended', () => {
  replayBtn2.style.display = 'block';
})

function showEnvelope() {
  envelope.style.display = 'flex';
}

function hideEnvelope() {
  envelope.style.display = 'none';
}

function showClosingScene() {
  envelope.style.display = 'none';
  paper.style.display = 'none';
  replayBtn.style.display = 'none';
  closingWrapper.style.display = 'flex';
  closingScene.currentTime = 0;
  closingScene.play();
}

replayBtn.addEventListener('click', () => {
  replayBtn.style.display = 'none';
  closingWrapper.style.display = 'none';
  replaySceneWrapper.style.display = 'flex';

  replayScene.currentTime = 0;
  replayScene.play();
})

replayBtn2.addEventListener('click', () => {
  replayBtn2.style.display = 'none';
  replaySceneWrapper.style.display = 'flex';

  replayScene.currentTime = 0;
  replayScene.play();
})
